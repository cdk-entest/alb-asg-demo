zip pub-ec2-web.zip -r * . 
aws s3 cp pub-ec2-web.zip s3://haimtran-workspace/